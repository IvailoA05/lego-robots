#!/usr/bin/env pybricks-micropython
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile

ev3 = EV3Brick()


leftMotor = Motor(Port.B)
rightMotor = Motor(Port.C)
color1 = ColorSensor(Port.S1)
#ultra UltrasonicSensor(Port.S4)
arm = Motor(Port.D)
color2 = ColorSensor(Port.S2)
gyro = GyroSensor(Port.S3)

robot = DriveBase(leftMotor, rightMotor, 56, 1250)

def move_forward_with_gyro(distance, direction, final_speed):
    gyro.reset_angle(0)
    last_error = 0
    pk = 0.4
    pd = 2
    speed = 0
    current_traveled_distance = robot.distance()
    while abs(robot.distance() - current_traveled_distance) <= abs(distance):
        error = 0 - gyro.angle()
        P = error * pk
        deriv = error -last_error
        D = deriv * pd
        last_error = error
        steering = P + D
        if speed > final_speed / 2:
            speed -= 1
        else:
            speed +=1
        robot.drive(speed * direction, steering)
        wait(3)
    robot.stop(Stop.BRAKE)

def turn_left_with_gyro(angle):
    if angle > 0:
        angle = -angle
    gyro.reset_angle(0)
    while gyro.angle() > angle:
        robot.drive(0,-2)
    robot.stop(Stop.BRAKE)

def turn_right_with_gyro(angle):
    if angle < 0:
        angle = -angle
    gyro.reset_angle(0)
    while gyro.angle() < angle:
        robot.drive(0,2)
    robot.stop(Stop.BRAKE)

move_forward_with_gyro(250, 1, 400)
turn_left_with_gyro(45)
move_forward_with_gyro(517, 1, 400)
arm.run_angle(200, 280, Stop.HOLD)
turn_left_with_gyro(41)
move_forward_with_gyro(300, 1, 400)
turn_left_with_gyro(25)
move_forward_with_gyro(420, 1, 400)
turn_left_with_gyro(40)
move_forward_with_gyro(470, 1, 400)
turn_left_with_gyro(45)
move_forward_with_gyro(50, 1, 400)
arm.run_angle(200, -180, Stop.HOLD)
arm.run_angle(200, 80, Stop.HOLD)
move_forward_with_gyro(150, -1, 400)
arm.run_angle(200, -180, Stop.HOLD)

turn_left_with_gyro(170)
move_forward_with_gyro(300, 1, 400)
turn_right_with_gyro(70)
move_forward_with_gyro(500, 1, 400)
turn_right_with_gyro(90)
move_forward_with_gyro(750, 1, 400)
turn_right_with_gyro(70)
move_forward_with_gyro(80, 1, 400)
move_forward_with_gyro(150, -1, 400)
turn_left_with_gyro(160)
move_forward_with_gyro(400, 1, 400)
turn_left_with_gyro(35)
move_forward_with_gyro(200, 1, 400)
turn_right_with_gyro(25)
move_forward_with_gyro(200, 1, 400)
turn_right_with_gyro(140)
move_forward_with_gyro(700, 1, 400)
move_forward_with_gyro(200, -1, 400)