#!/usr/bin/env pybricks-micropython
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile

ev3 = EV3Brick()

passed_colors = []
x_colors = [Color.GREEN, Color.RED, Color.BLUE, Color.YELLOW]
y_colors = [Color.GREEN, Color.RED, Color.BLUE, Color.YELLOW]
gate_to_enter = 0
i_gate_to_enter = 0

leftMotor = Motor(Port.B)
rightMotor = Motor(Port.C)
color1 = ColorSensor(Port.S1)
#ultra UltrasonicSensor(Port.S4)
arm = Motor(Port.D)
color2 = ColorSensor(Port.S2)

robot = DriveBase(leftMotor, rightMotor, 56, 1000)
for i in range(5):
    robot.drive(200,0)
    while color1.color() != Color.WHITE:
       pass
    while color1.color() == Color.WHITE:
       pass
    robot.straight(10)
    robot.stop(Stop.BRAKE)
    wait(200)
    if i == 0:
        gate_to_enter = color1.color()
        for i, color in enumerate(x_colors):
            if color == gate_to_enter:
                i_gate_to_enter = i+1
    passed_colors.append(color1.color())
print("Detected colors:", passed_colors)
print("Gate that should be entered:", i_gate_to_enter)

x_block_coord = passed_colors[1]
y_block_coord = passed_colors[2]

i_x_block_coord = 0
i_y_block_coord = 0

for i, color in enumerate(x_colors):
    if color == x_block_coord:
        i_x_block_coord = i+1

for i, color in enumerate(y_colors):
    if color == y_block_coord:
        i_y_block_coord = i+1
    
print("First block x coord:", i_x_block_coord)
print("First block y coord:", i_y_block_coord)

lines_to_y_coord = i_y_block_coord - i_gate_to_enter
if lines_to_y_coord < 0:
    lines_to_y_coord = -lines_to_y_coord
print("Lines to y coord:",lines_to_y_coord)

x_lines_to_container = (len(x_colors) - i_x_block_coord) - 1
y_lines_to_container = len(y_colors) - i_y_block_coord

print("X lines to container when done:", x_lines_to_container)
print("Y lines to container when done:", y_lines_to_container)

done_detecting_black_line = False

while not done_detecting_black_line:
    robot.drive(200,0)
    while color1.color() != Color.BLACK:
       pass
    robot.stop(Stop.BRAKE)
    done_detecting_black_line = True
wait(500)

current_gate = 0
passed_black = True
done_traveling_to_gate = False
while not done_traveling_to_gate:
    if color1.reflection() > 60:
        robot.drive(0, -4)
    elif color1.reflection() < 20:
        robot.drive(0, 4)
    else:
        robot.drive(120,0)

    if color2.color() == Color.BLACK and passed_black:
        current_gate+=1
        if current_gate == i_gate_to_enter:
            robot.stop(Stop.BRAKE)
            done_traveling_to_gate = True
        passed_black = False

    if color2.color() == Color.WHITE:
        passed_black = True

robot.drive(70, 5)
wait(1000)
robot.stop(Stop.BRAKE)
wait(100)
robot.drive(-5, 5)
wait(700)

same_gate = False
if i_y_block_coord == i_gate_to_enter:
    same_gate = True

for i in range(i_x_block_coord):
    if i+1 == i_x_block_coord and same_gate:
        robot.straight(150)
        robot.stop(Stop.BRAKE)
    else:
        robot.drive(100, 0)
        while color1.color() != Color.WHITE:
            pass
        done_aligning_on_intersection = False
        while not done_aligning_on_intersection:
            if color1.color() == Color.WHITE and color2.color() == Color.WHITE:
                robot.drive(100, 0)
            elif color1.color() == Color.BLACK and color2.color() == Color.BLACK:
                robot.stop(Stop.BRAKE)
                wait(100)
                done_aligning_on_intersection = True
            elif color1.color() != Color.WHITE:
                robot.drive(70, -5)
            elif color2.color() != Color.WHITE:
                robot.drive(70, 5)

        done_aligning_on_intersection = False
        if i+1 == i_x_block_coord and not same_gate:
            robot.straight(50)
            wait(1000)
            print(True)

is_turned_left = False
is_turned_right = False
if i_gate_to_enter > i_y_block_coord:
    robot.turn(10) # Left
    is_turned_left = True
elif i_gate_to_enter < i_y_block_coord:
    robot.turn(-10) # Right
    is_turned_right = True
else:
    robot.stop(Stop.BRAKE)

for i in range(lines_to_y_coord):
    if i+1 == lines_to_y_coord:
        robot.straight(85)
        robot.stop(Stop.BRAKE)
    else:
        robot.drive(100, 0)
        while color1.color() != Color.WHITE:
            pass
        done_aligning_on_intersection = False
        while not done_aligning_on_intersection:
            if color1.color() == Color.WHITE and color2.color() == Color.WHITE:
                robot.drive(100, 0)
            elif color1.color() == Color.BLACK and color2.color() == Color.BLACK:
                robot.stop(Stop.BRAKE)
                wait(100)
                done_aligning_on_intersection = True
            elif color1.color() != Color.WHITE:
                robot.drive(70, -5)
            elif color2.color() != Color.WHITE:
                robot.drive(70, 5)

        done_aligning_on_intersection = False
arm.run_angle(100, 200, Stop.HOLD)
print("It picked the container up!")
wait(100)

done_aligning_on_intersection = False
while not done_aligning_on_intersection:
    if color1.color() == Color.WHITE and color2.color() == Color.WHITE:
        robot.drive(100, 0)
    elif color1.color() == Color.BLACK and color2.color() == Color.BLACK:
        robot.stop(Stop.BRAKE)
        wait(100)
        done_aligning_on_intersection = True
    elif color1.color() != Color.WHITE:
        robot.drive(70, -5)
    elif color2.color() != Color.WHITE:
        robot.drive(70, 5)


robot.straight(75)
wait(1000)
robot.stop(Stop.BRAKE)


if is_turned_left == True:
    robot.turn(-10)
    wait(1000)
elif is_turned_right == True:
    robot.turn(10)
    wait(1000)
else:
    robot.stop(Stop.BRAKE)

for i in range(x_lines_to_container):
    robot.drive(100, 0)
    while color1.color() != Color.WHITE:
        pass
    done_aligning_on_intersection = False
    while not done_aligning_on_intersection:
        if color1.color() == Color.WHITE and color2.color() == Color.WHITE:
            robot.drive(100, 0)
        elif color1.color() == Color.BLACK and color2.color() == Color.BLACK:
            robot.stop(Stop.BRAKE)
            wait(100)
            done_aligning_on_intersection = True
        elif color1.color() != Color.WHITE:
            robot.drive(70, -5)
        elif color2.color() != Color.WHITE:
            robot.drive(70, 5)
    
robot.straight(75)
wait(100)

robot.turn(-10)
wait(100)

for i in range(y_lines_to_container):
    robot.drive(100, 0)
    while color1.color() != Color.WHITE:
        pass
    done_aligning_on_intersection = False
    while not done_aligning_on_intersection:
        if color1.color() == Color.WHITE and color2.color() == Color.WHITE:
            robot.drive(100, 0)
        elif color1.color() == Color.BLACK and color2.color() == Color.BLACK:
            robot.stop(Stop.BRAKE)
            wait(100)
            done_aligning_on_intersection = True
        elif color1.color() != Color.WHITE:
            robot.drive(70, -5)
        elif color2.color() != Color.WHITE:
            robot.drive(70, 5)

arm.run_angle(100, -200, Stop.HOLD)
print("It dropped the container down!")
wait(1000)

robot.drive(-70, 0)
wait(1000)